COTWSaveManager v1.0 install instructions

This tool requires little installation process:
1) Create a folder anywhere on your computer for the tool
2) Extract all files to that folder
3) Enjoy!

The tool will keep all inactive saves under %appdata%/COTWSaveManager/